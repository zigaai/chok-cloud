/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.101.220
 Source Server Type    : MySQL
 Source Server Version : 80033 (8.0.33)
 Source Host           : 192.168.101.220:3306
 Source Schema         : chok_authorization

 Target Server Type    : MySQL
 Target Server Version : 80033 (8.0.33)
 File Encoding         : 65001

 Date: 16/07/2023 21:57:42
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for oauth2_authorization_consent
-- ----------------------------
DROP TABLE IF EXISTS `oauth2_authorization_consent`;
CREATE TABLE `oauth2_authorization_consent`  (
  `registered_client_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `principal_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `authorities` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`registered_client_id`, `principal_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of oauth2_authorization_consent
-- ----------------------------

-- ----------------------------
-- Table structure for oauth2_registered_client
-- ----------------------------
DROP TABLE IF EXISTS `oauth2_registered_client`;
CREATE TABLE `oauth2_registered_client`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `client_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户端ID',
  `client_id_issued_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `client_secret` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户端密钥',
  `client_secret_expires_at` datetime NULL DEFAULT NULL,
  `client_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户端名称',
  `client_authentication_methods` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '认证方式, 多个,隔开: \r\nclient_secret_basic',
  `authorization_grant_types` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '授权方式, 多个,隔开: \r\n授权码: authorization_code',
  `redirect_uris` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '回调地址, 多个,隔开',
  `scopes` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '作用域, 多个,隔开',
  `client_settings` json NOT NULL,
  `token_settings` json NOT NULL,
  `post_logout_redirect_uris` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_client_id`(`client_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of oauth2_registered_client
-- ----------------------------
INSERT INTO `oauth2_registered_client` VALUES (1, 'messaging-client', '2023-07-01 17:16:55', '{bcrypt}$2a$10$E0dUqSYjJnSsFosTaR0R2.S65kI1ROx5W/7ogV/yC3KlsG0F7Sn76', NULL, '03ef62a2-de94-4257-a99d-63b1d7e2a4c4', 'client_secret_basic', 'refresh_token,client_credentials,authorization_code', 'http://127.0.0.1:9000/oauth2/authorize,https://cn.bing.com', 'message.read,message.write', '{\"settings.client.require-proof-key\": false, \"settings.client.require-authorization-consent\": true}', '{\"settings.token.access-token-format\": null, \"settings.token.reuse-refresh-tokens\": true, \"settings.token.access-token-time-to-live\": 3600, \"settings.token.refresh-token-time-to-live\": 3600, \"settings.token.id-token-signature-algorithm\": \"RS256\", \"settings.token.authorization-code-time-to-live\": 300}', NULL);
INSERT INTO `oauth2_registered_client` VALUES (2, 'oidc-client', '2023-01-22 16:01:39', '{bcrypt}$2a$10$E0dUqSYjJnSsFosTaR0R2.S65kI1ROx5W/7ogV/yC3KlsG0F7Sn76', NULL, 'b4124c67-951e-4b99-b3a0-891ac39be945', 'client_secret_basic', 'refresh_token,client_credentials,authorization_code', 'http://127.0.0.1:8080/authorized,http://127.0.0.1:8080/login/oauth2/code/oidc-client-oidc,https://cn.bing.com', 'openid,client.create,client.read', '{\"settings.client.require-proof-key\": false, \"settings.client.require-authorization-consent\": true}', '{\"settings.token.access-token-format\": null, \"settings.token.reuse-refresh-tokens\": true, \"settings.token.access-token-time-to-live\": 3600, \"settings.token.refresh-token-time-to-live\": 3600, \"settings.token.id-token-signature-algorithm\": \"RS256\", \"settings.token.authorization-code-time-to-live\": 300}', NULL);

SET FOREIGN_KEY_CHECKS = 1;
